export default class Contacto {
  constructor(identificacion, nombre, apellido, correo, celular) {
    this.identificacion = identificacion;
    this.nombre = nombre;
    this.apellido = apellido;
    this.correo = correo;
    this.celular = celular;
  }
}
