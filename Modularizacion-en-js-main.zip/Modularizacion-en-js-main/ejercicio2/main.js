import { calcularDescuento } from "./utilidades.js";

console.log(calcularDescuento(1500)); 
console.log(calcularDescuento(1200)); 
console.log(calcularDescuento(1000)); 
console.log(calcularDescuento(750));  
console.log(calcularDescuento(500));  
console.log(calcularDescuento(400));  
console.log(calcularDescuento(100)); 
