import { esElegibleParaPrestamo } from "./utilidades.js";

console.log(esElegibleParaPrestamo(4000000, 700));  
console.log(esElegibleParaPrestamo(2500000, 700));  
console.log(esElegibleParaPrestamo(3500000, 600));  
console.log(esElegibleParaPrestamo(5000000, 800));  
