import { nivRiesgo } from "./utilidades.js";

console.log(nivRiesgo(65, false));   
console.log(nivRiesgo(50, true));    
console.log(nivRiesgo(30, false));   
console.log(nivRiesgo(45, false));
