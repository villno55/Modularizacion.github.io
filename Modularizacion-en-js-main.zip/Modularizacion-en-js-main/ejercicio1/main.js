import { enRango } from "./enRango.js";

console.log(enRango(25));  
console.log(enRango(5));   
console.log(enRango(10));  
console.log(enRango(50));  
console.log(enRango(70));  


