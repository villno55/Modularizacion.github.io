import { categoriaIMC } from "./utilidades.js";

console.log(categoriaIMC(17));    
console.log(categoriaIMC(22));    
console.log(categoriaIMC(27));    
console.log(categoriaIMC(32));    
console.log(categoriaIMC(18.5));  
console.log(categoriaIMC(24.9));  
