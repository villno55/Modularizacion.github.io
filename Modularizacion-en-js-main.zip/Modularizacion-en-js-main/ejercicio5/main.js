import { esBisiesto } from "./utilidades.js";

console.log(esBisiesto(2024));  
console.log(esBisiesto(2023));  
console.log(esBisiesto(2000));
console.log(esBisiesto(2100)); 
